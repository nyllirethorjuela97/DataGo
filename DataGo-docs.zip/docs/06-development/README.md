# 06 — Development

Esta carpeta contiene el roadmap de desarrollo y las reglas que gobiernan cómo se construye DataGo — **no contiene código**, solo la planificación y las reglas para cuando el desarrollo sea aprobado.

| Documento | Contenido |
|---|---|
| [`roadmap.md`](./roadmap.md) | Fases 0–10 del desarrollo, desde arquitectura hasta QA/seguridad/deployment |
| [`development-rules.md`](./development-rules.md) | Reglas de desarrollo, principios de confiabilidad de IA, observabilidad, versionado, testing, MVP, monetización y checkpoint de aprobación |

## Estado actual del proyecto

```text
STATUS: ARCHITECTURE DEFINITION

PRODUCT: DEFINED
VISION: DEFINED
CONCEPT: DEFINED
MVP: DEFINED
TECH STACK: PROPOSED
AGENT MODEL: PROPOSED
DATA MODEL: CONCEPTUAL
UX: CONCEPTUAL
ORCHESTRATOR: TO BE DETAILED

DEVELOPMENT: NOT STARTED
```

## Siguiente paso

El siguiente paso **no es desarrollar**. Es completar la revisión y aprobación explícita de los documentos producidos en esta carpeta `/docs`:

```text
Functional Architecture
Technical Architecture
Agent Architecture
Orchestrator Architecture
Data Architecture
Security Architecture
Multi-Tenancy Architecture
UX / Navigation
Data Model
Development Roadmap
```

Después de revisar y aprobar estos documentos:

```text
ARCHITECTURE APPROVED
        ↓
DEVELOPMENT START
        ↓
GITHUB
        ↓
VERCEL
        ↓
CONVEX
        ↓
DATAGO MVP
```
