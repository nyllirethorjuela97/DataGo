# Development Rules

## 1. Reglas de desarrollo

| # | Regla |
|---|---|
| 1 | No construir funcionalidades fuera del alcance aprobado |
| 2 | No cambiar arquitectura silenciosamente |
| 3 | No almacenar secretos en GitHub |
| 4 | No exponer API keys en frontend |
| 5 | Todo Agent Run debe ser trazable |
| 6 | Todo insight importante debe tener evidencia |
| 7 | El Orchestrator controla la ejecución de agentes |
| 8 | Los agentes deben tener responsabilidades específicas |
| 9 | La IA no debe inventar datos |
| 10 | El MVP debe mantenerse pequeño |

Estas reglas son vinculantes para cualquier agente de desarrollo (humano o de IA) que trabaje sobre el repositorio.

## 2. AI Reliability Principles

DataGo debe diferenciar siempre:

```text
FACT
INTERPRETATION
HYPOTHESIS
RECOMMENDATION
```

Nunca deben presentarse como equivalentes. Cuando no exista suficiente evidencia, el sistema debe **expresar incertidumbre** en lugar de generar una conclusión artificialmente segura.

Esta regla es la base de: `04-data/data-architecture.md` (modelo Evidence/Insight/Hypothesis/Opportunity/Recommendation) y de las validaciones del Orchestrator (`03-agents/orchestrator-architecture.md` §6).

## 3. Observability

Cada ejecución de agente debe poder registrar:

```text
agent · version · project · task · input · output · status
duration · model · tokens/usage · errors · validation · timestamp
```

Ver `02-architecture/technical-architecture.md` §6 y el campo por campo en `04-data/data-model.md` (entidad `AgentRun`).

## 4. Versioning

Deben ser versionables: agents, prompts, workflows, tools, scoring logic, schemas, product specifications.

Consecuencia directa: ningún cambio sobre un agente, prompt o workflow en producción debe sobrescribir silenciosamente el comportamiento anterior sin quedar registrado como una nueva versión trazable (relacionado con Regla 2, "no cambiar arquitectura silenciosamente").

## 5. Testing

| Tipo | Alcance |
|---|---|
| **Unit Tests** | Funciones críticas |
| **Integration Tests** | Convex, workflows, agentes, procesamiento de datos |
| **End-to-End Tests** | `Create Project → Challenge → Data → Run → Intelligence → Opportunity → Output` |
| **AI Evaluation** | Factuality, evidence grounding, consistency, usefulness, hallucination rate |

El flujo de End-to-End Tests debe corresponder exactamente al flujo funcional definido en `02-architecture/functional-architecture.md` §2.

## 6. MVP — alcance mínimo aprobado

Incluido:

```text
Workspace → Project → Challenge → Data → Agent Orchestration
   → Intelligence → Opportunities → Output
```

Agentes requeridos en el MVP: Data Agent, Shopper Agent, Research Agent, Insight Agent, Opportunity Agent. Trade, Strategy, Solution y Proposal Agent se incorporan después, sin requerir reconstrucción del sistema (ver `03-agents/agent-catalog.md`).

Fuera de alcance del MVP: enterprise billing, white label, marketplace, mobile app, CRM avanzado, contabilidad, automatización compleja, colaboración avanzada, integraciones externas complejas, generación avanzada de propuestas, Strategy Workspace completo (ver `05-ux/user-journeys.md` §5).

## 7. Monetization (preparación arquitectónica, no implementación MVP)

DataGo debe **prepararse** para los siguientes modelos, sin que su implementación bloquee el MVP:

| Modelo | Descripción |
|---|---|
| Free / Trial | Acceso limitado |
| Professional | Mayor capacidad de proyectos y análisis |
| Team | Colaboración y workspaces |
| Enterprise | Seguridad, administración y escalabilidad |
| Premium Agents | Agentes especializados |
| Analysis Consumption | Cobro por consumo de análisis o IA |
| Private Workspaces | Workspaces privados para organizaciones |
| White Label | Capacidad futura para clientes empresariales |

## 8. Architectural Decisions Required (antes de desarrollar)

1. Arquitectura exacta del Orchestrator
2. Estrategia de ejecución síncrona/asíncrona
3. Estrategia de memoria
4. Modelo final de datos
5. Sistema de permisos
6. Sistema multi-tenant
7. AI provider abstraction
8. Tool architecture
9. File processing
10. Evidence model
11. Agent evaluation
12. Observability
13. Deployment architecture

Cada una de estas decisiones está referenciada a su documento correspondiente en `02-architecture/technical-architecture.md` §8.

## 9. Architectural Checkpoint

Antes de comenzar el desarrollo (PHASE 1 del roadmap) debe existir **aprobación explícita** de:

```text
Product Architecture
Functional Architecture
Technical Architecture
Agent Architecture
Orchestrator Architecture
Data Architecture
UX Architecture
Security Architecture
MVP Scope
Development Roadmap
```

Este checkpoint es el criterio de salida de PHASE 0. Sin esta aprobación explícita registrada, ningún desarrollo de producción debe iniciarse (Regla fundamental de `DATAGO_MASTER_SPEC.md` §0).

## 10. Instrucción para cualquier agente de desarrollo

> **READ THE MASTER SPEC BEFORE DEVELOPING.**

Todo agente de desarrollo (humano o de IA) que trabaje sobre DataGo debe:

1. leer `DATAGO_MASTER_SPEC.md`;
2. revisar la documentación complementaria en `/docs`;
3. identificar decisiones pendientes (§8 de este documento);
4. no inventar arquitectura;
5. no comenzar desarrollo antes de la aprobación (§9 de este documento);
6. respetar el alcance del MVP (§6 de este documento);
7. documentar cambios;
8. mantener trazabilidad;
9. evitar funcionalidades innecesarias;
10. pedir aprobación ante cambios arquitectónicos importantes.

## 11. Principio final

DataGo no debe construirse como una colección de funcionalidades. Debe construirse como un **sistema inteligente orientado a resolver retos de negocio**. La experiencia central debe permanecer:

```text
CHALLENGE → UNDERSTAND → INVESTIGATE → ANALYZE → UNDERSTAND
   → IDENTIFY OPPORTUNITIES → RECOMMEND → ACT
```

El objetivo del MVP es demostrar que DataGo puede convertir un reto real en **inteligencia útil y oportunidades accionables**. Todo desarrollo futuro debe fortalecer esta propuesta central.
