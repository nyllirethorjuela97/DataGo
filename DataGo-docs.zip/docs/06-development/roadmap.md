# Development Roadmap

> **No coding.** Este roadmap se activa únicamente después de la aprobación explícita de la arquitectura (ver `development-rules.md` §Architectural Checkpoint).

## PHASE 0 — Architecture

Definir y aprobar: product architecture, technical architecture, agent architecture, orchestrator, data model, UX, MVP.

**Entregable de esta fase:** los documentos contenidos en `/docs` (este mismo conjunto de documentación).

## PHASE 1 — Foundation

Crear: Next.js, TypeScript, estructura del proyecto, GitHub, Vercel, Convex, configuración de entorno, sistema de UI base.

## PHASE 2 — Workspace / Projects

Crear: users, organizations, workspaces, projects, permissions.
Referencias: `02-architecture/multi-tenancy-architecture.md`, `04-data/data-model.md`.

## PHASE 3 — Challenge

Crear: Challenge Builder, modelo de challenge, validación de challenge, contexto de challenge.
Referencias: `01-product/README.md` §9.3, `02-architecture/functional-architecture.md` §3.

## PHASE 4 — Data Hub

Crear: sources, files, datasets, storage, ingestion, procesamiento básico.
Referencias: `04-data/data-architecture.md` §9 (File processing, decisión pendiente).

## PHASE 5 — Orchestrator

Crear: Agent Registry, Tool Registry, Workflow, Task, Agent Run, Execution State, Context, Validation, Error handling.
Referencias: `03-agents/orchestrator-architecture.md`.

## PHASE 6 — Agents

Implementar inicialmente: Data Agent, Shopper Agent, Research Agent, Insight Agent, Opportunity Agent.
Referencias: `03-agents/agent-catalog.md`.

## PHASE 7 — Intelligence

Crear: Evidence, Insights, Hypotheses, Intelligence Board, trazabilidad.
Referencias: `04-data/data-architecture.md` §1–4.

## PHASE 8 — Opportunities

Crear: Opportunity Engine, priorización, recomendaciones.
Referencias: `04-data/data-architecture.md` §5–6.

## PHASE 9 — Output

Crear: executive summary, reportes básicos, outputs exportables.
Referencias: `05-ux/user-journeys.md` §4 (Output mínimo del MVP).

## PHASE 10 — QA / Security / Deployment

Validar: authentication, authorization, data isolation, error handling, performance, AI reliability, security, deployment.
Referencias: `02-architecture/security-architecture.md`, `development-rules.md` §Testing.

## Resumen visual

```text
PHASE 0  ARCHITECTURE            (no coding)
PHASE 1  FOUNDATION
PHASE 2  WORKSPACE / PROJECTS
PHASE 3  CHALLENGE
PHASE 4  DATA HUB
PHASE 5  ORCHESTRATOR
PHASE 6  AGENTS (Data, Shopper, Research, Insight, Opportunity)
PHASE 7  INTELLIGENCE
PHASE 8  OPPORTUNITIES
PHASE 9  OUTPUT
PHASE 10 QA / SECURITY / DEPLOYMENT
```

## Regla de secuencia

Ninguna fase debe adelantarse a la anterior. En particular, **PHASE 1 no puede comenzar** hasta que PHASE 0 (esta documentación) esté formalmente aprobada — ver `development-rules.md` §Architectural Checkpoint.
