# 05 — UX / Navigation

Esta carpeta define cómo navega el usuario dentro de DataGo y los journeys principales.

| Documento | Contenido |
|---|---|
| [`navigation-map.md`](./navigation-map.md) | Mapa de navegación global y navegación dentro de un proyecto |
| [`user-journeys.md`](./user-journeys.md) | Experiencia de usuario completa, journey del MVP y ejemplo de proyecto real |

Estos documentos operacionalizan las secciones 8, 38–40 y 43 de `DATAGO_MASTER_SPEC.md`.
