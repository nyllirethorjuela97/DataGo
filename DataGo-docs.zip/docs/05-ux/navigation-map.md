# Navigation Map

## 1. Navegación global

```text
HOME
│
├── WORKSPACES
│   │
│   └── PROJECTS
│       │
│       ├── Overview
│       ├── Challenge
│       ├── Data
│       ├── Agents
│       ├── Intelligence
│       ├── Opportunities
│       ├── Strategy
│       └── Deliverables
│
├── AGENT HUB
│
├── KNOWLEDGE
│
└── ADMIN
```

| Nodo | Módulo de producto asociado | MVP |
|---|---|---|
| Workspaces → Projects | Workspace, Projects | Sí |
| Agent Hub | Agent Hub | Sí |
| Knowledge | Knowledge Base | Versión inicial |
| Admin | Administration | No (post-MVP) |

## 2. Navegación dentro de un proyecto

```text
PROJECT
│
├── Overview
├── Challenge
├── Data
├── Agent Runs
├── Intelligence
├── Opportunities
├── Recommendations
├── Strategy
└── Deliverables
```

| Sección | Propósito | Módulo relacionado | MVP |
|---|---|---|---|
| Overview | Estado general del proyecto y su challenge activo | Project | Sí |
| Challenge | Definir/editar el reto estructurado | Challenge Builder | Sí |
| Data | Gestionar fuentes del proyecto | Data Hub | Sí |
| Agent Runs | Ver ejecuciones de agentes, su estado y trazabilidad | Agent Orchestrator | Sí |
| Intelligence | Evidencia, insights e hipótesis | Intelligence Board | Sí |
| Opportunities | Oportunidades priorizadas | Opportunity Engine | Sí |
| Recommendations | Recomendaciones accionables ligadas a oportunidades | Opportunity Engine | Sí |
| Strategy | Dirección estratégica derivada de oportunidades | Strategy Workspace | No (post-MVP) |
| Deliverables | Entregables generados | Deliverables | Sí (versión mínima: executive summary) |

## 3. Principio de navegación

La navegación dentro de un proyecto **refleja el flujo funcional** definido en `02-architecture/functional-architecture.md` (Challenge → Data → Agents/Orchestration → Intelligence → Opportunities → Recommendations → Strategy → Deliverables). No se introduce ninguna sección de navegación que no corresponda a un paso de ese flujo o a un módulo de producto documentado en `01-product/README.md`.
