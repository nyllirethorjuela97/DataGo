# User Journeys

## 1. Experiencia de usuario completa

```text
LOGIN
  ↓
WORKSPACE
  ↓
PROJECT
  ↓
NEW CHALLENGE
  ↓
DATA SOURCES
  ↓
ORCHESTRATOR
  ↓
AGENTS
  ↓
ANALYSIS
  ↓
INTELLIGENCE BOARD
  ↓
OPPORTUNITIES
  ↓
RECOMMENDATIONS
  ↓
ACTION
  ↓
DELIVERABLES
```

## 2. Journey del MVP

```text
LOGIN
 ↓
CREATE WORKSPACE
 ↓
CREATE PROJECT
 ↓
DEFINE CHALLENGE
 ↓
ADD DATA
 ↓
RUN ANALYSIS
 ↓
ORCHESTRATOR
 ↓
AGENTS
 ↓
INTELLIGENCE BOARD
 ↓
OPPORTUNITIES
 ↓
OUTPUT
```

Este journey es deliberadamente el **subconjunto mínimo** del journey completo (§1): omite Strategy y limita Deliverables a un output mínimo (ver `06-development/roadmap.md` PHASE 9 y §MVP Output más abajo).

## 3. Ejemplo de proyecto real

**Challenge:** *"Quiero entender cómo crecer en una categoría."*

DataGo debería producir:

```text
CHALLENGE
   ↓
SOURCE IDENTIFICATION
   ↓
DATA COLLECTION
   ↓
AGENT PLANNING
   ↓
DATA AGENT
   ↓
SHOPPER AGENT
   ↓
RESEARCH AGENT
   ↓
INSIGHT AGENT
   ↓
EVIDENCE
   ↓
HYPOTHESES
   ↓
OPPORTUNITIES
   ↓
RECOMMENDATIONS
   ↓
OUTPUT
```

Nota importante: **no todos los agentes deben ejecutarse obligatoriamente**. El Orchestrator determina cuáles son necesarios según el challenge concreto (ver `03-agents/orchestrator-architecture.md` §5, Agent Selection). Este diagrama muestra el camino más completo posible dentro del alcance del MVP, no un pipeline fijo.

## 4. Output mínimo del MVP

El MVP debe entregar como mínimo:

- resumen del challenge
- principales evidencias
- insights
- hipótesis
- oportunidades
- recomendaciones
- resumen ejecutivo

## 5. Fuera de alcance del MVP

No se desarrolla inicialmente: enterprise billing, white label, marketplace, mobile app, CRM avanzado, contabilidad, automatización compleja, colaboración avanzada, integraciones externas complejas, generación avanzada de propuestas, Strategy Workspace completo.

Estas funcionalidades están contempladas en la arquitectura futura (`06-development/roadmap.md`), pero no bloquean ni condicionan el diseño de los journeys anteriores.
