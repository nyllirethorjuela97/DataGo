# DataGo — Documentación Arquitectónica

**Estado del proyecto:** `ARCHITECTURE DEFINITION` · **Desarrollo:** `NOT STARTED`

Este directorio contiene la documentación arquitectónica detallada de **DataGo**, derivada y expandida a partir de `DATAGO_MASTER_SPEC.md` (fuente de verdad del producto).

> **Regla fundamental:** ningún desarrollo de producción debe comenzar hasta que todos los documentos de esta carpeta hayan sido revisados y aprobados explícitamente (ver `06-development/development-rules.md`, sección "Architectural Checkpoint").

## Mapa de la documentación

| Carpeta | Contenido | Documentos |
|---|---|---|
| [`01-product/`](./01-product/README.md) | Arquitectura de producto: visión, problema, usuarios, propuesta de valor, módulos de la plataforma | `README.md` |
| [`02-architecture/`](./02-architecture/README.md) | Arquitectura funcional, técnica, de seguridad y multi-tenancy | `functional-architecture.md`, `technical-architecture.md`, `security-architecture.md`, `multi-tenancy-architecture.md` |
| [`03-agents/`](./03-agents/README.md) | Arquitectura de agentes, orquestador y human-in-the-loop | `orchestrator-architecture.md`, `agent-catalog.md`, `human-in-the-loop.md` |
| [`04-data/`](./04-data/README.md) | Arquitectura de datos, modelo de entidades, modelo de inteligencia y evidencia | `data-architecture.md`, `data-model.md` |
| [`05-ux/`](./05-ux/README.md) | Navegación, experiencia de usuario y journeys | `navigation-map.md`, `user-journeys.md` |
| [`06-development/`](./06-development/README.md) | Roadmap de desarrollo, reglas, MVP, testing, monetización y checkpoint de aprobación | `roadmap.md`, `development-rules.md` |

## Cómo leer esta documentación

1. Empieza por `01-product/README.md` para entender **qué es DataGo y por qué existe**.
2. Continúa con `02-architecture/functional-architecture.md` para entender **cómo fluye el producto de extremo a extremo**.
3. Sigue con `02-architecture/technical-architecture.md` para entender **con qué se construye**.
4. Profundiza en `03-agents/` para entender **quién ejecuta el trabajo de inteligencia** (los agentes y el orquestador).
5. Revisa `04-data/` para entender **qué se almacena y cómo se modela la evidencia y la inteligencia**.
6. Revisa `05-ux/` para entender **cómo navega el usuario**.
7. Cierra con `06-development/roadmap.md` para entender **el orden de construcción** y las reglas de desarrollo.

## Principio rector

```text
CHALLENGE → UNDERSTAND → INVESTIGATE → ANALYZE → UNDERSTAND
    → IDENTIFY OPPORTUNITIES → RECOMMEND → ACT
```

DataGo no es una colección de funcionalidades: es un **sistema inteligente orientado a resolver retos de negocio**. Toda decisión arquitectónica documentada aquí debe evaluarse contra este principio.

## Trazabilidad respecto a la Master Spec

Esta documentación **no reemplaza** `DATAGO_MASTER_SPEC.md`; lo **detalla y operacionaliza**. Cuando exista cualquier ambigüedad o conflicto, `DATAGO_MASTER_SPEC.md` prevalece como fuente de verdad, y cualquier desviación debe registrarse explícitamente como una decisión arquitectónica (ver `06-development/development-rules.md`).
