# Security Architecture

## 1. Principios rectores

DataGo maneja información comercial sensible (datos de shopper, mercado, clientes) en un entorno multi-tenant con agentes de IA que ejecutan acciones autónomas. La seguridad se organiza en cuatro pilares:

```text
SECRETS  →  AUTHORIZATION  →  DATA ISOLATION  →  AUDITABILITY
```

## 2. Secrets

**Regla:** nunca almacenar API keys, contraseñas, tokens ni credenciales privadas en el repositorio.

- Todas las credenciales viven en variables de entorno gestionadas por la plataforma de despliegue (Vercel) y/o el backend (Convex), nunca en código versionado.
- `.env.example` documenta las variables requeridas **sin valores reales**.
- Ninguna API key debe exponerse en el frontend (Master Spec Rule 4): toda llamada a proveedores de IA o servicios externos pasa por la capa de aplicación/backend, nunca directamente desde el navegador.

## 3. Authorization

**Regla:** la autorización se valida siempre en backend; el frontend nunca es la única barrera de control de acceso.

- Cada operación sobre una entidad (leer/crear/modificar un Project, Challenge, DataSource, etc.) debe verificar en el backend que el usuario autenticado tiene permiso sobre el Workspace/Organization al que pertenece esa entidad.
- Los agentes heredan permisos acotados: un Agent Run se ejecuta con el contexto de permisos del proyecto que lo originó, nunca con privilegios globales.
- Las herramientas (tools) declaran sus propios `permissions` (ver `technical-architecture.md` §4); un agente no puede invocar una tool fuera del alcance permitido por su definición en el Agent Hub.

## 4. Data Isolation

**Regla:** un usuario no debe poder acceder a información perteneciente a otra organización o workspace.

- El aislamiento se aplica en todos los niveles de la jerarquía multi-tenant (ver `multi-tenancy-architecture.md`): User, Team, Organization, Clients, Projects.
- Toda consulta a datos (evidencia, insights, datasets, knowledge) debe filtrarse por el `tenant scope` del usuario solicitante; no debe existir una vía de consulta que omita ese filtro, incluida la ejecutada por agentes.
- El Knowledge Base y Project Memory deben distinguir explícitamente conocimiento a nivel de proyecto, cliente y organización, para evitar que aprendizajes de un cliente se filtren a otro sin autorización explícita.

## 5. Auditability

**Regla:** las acciones importantes deben poder registrarse.

- Toda ejecución de agente (`AgentRun`) se registra con los campos definidos en Observability (`06-development/development-rules.md`).
- Cambios estructurales sobre un proyecto (challenge modificado, fuente añadida, oportunidad aprobada/rechazada) deben quedar en `AuditLogs` (ver `04-data/data-model.md`).
- Las decisiones humanas dentro de human-in-the-loop (aprobar / rechazar / modificar una recomendación del sistema) deben registrarse con quién, cuándo y sobre qué elemento de inteligencia.

## 6. AI-specific security considerations

Estas consideraciones son específicas de una plataforma agentic y complementan los cuatro pilares anteriores:

- **Contención de herramientas:** un agente solo puede usar las tools explícitamente asignadas a su definición; el Orchestrator no debe otorgar acceso ad-hoc.
- **No fabricar datos:** la IA no debe inventar datos (Master Spec Rule 9); esto es también un control de seguridad/integridad, no solo de calidad, porque una recomendación fabricada puede inducir una decisión de negocio incorrecta.
- **Aislamiento de contexto entre proyectos:** el contexto que recibe un agente en un `AgentRun` debe limitarse estrictamente al proyecto/challenge en curso, evitando fugas de contexto entre proyectos de distintos clientes dentro de la misma organización.
- **Validación de salidas antes de persistir:** ninguna salida de un agente se convierte en Evidence/Insight sin pasar por el paso `VALIDATING` del ciclo de vida del Agent Run (ver `functional-architecture.md` §4).

## 7. Relación con otras decisiones pendientes

El "Sistema de permisos" (rol/RBAC exacto) y el "AI provider abstraction" están listados como decisiones arquitectónicas pendientes en `technical-architecture.md` §8; este documento define los **principios** que cualquier diseño de permisos debe cumplir, no el modelo final de roles.
