# Technical Architecture

> **No coding.** Este documento describe la arquitectura técnica propuesta a nivel conceptual, para revisión y aprobación, no una implementación.

## 1. Vista de capas

```text
                         USER
                           │
                           ▼
                  VERCEL / FRONTEND        (Next.js + React + TypeScript)
                           │
                           ▼
                  APPLICATION LAYER         (rutas, server actions, API)
                           │
                           ▼
                  AGENT ORCHESTRATOR        (planificación y ejecución)
                           │
                           ▼
                       AI LAYER
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
             DATA         TOOLS      WORKFLOWS
              │            │            │
              └────────────┼────────────┘
                           ▼
                         CONVEX             (backend + base de datos + storage)
                           │
             ┌─────────────┼─────────────┐
             ▼             ▼             ▼
          PROJECTS        DATA       KNOWLEDGE
                           │
                           ▼
                        OUTPUTS
```

## 2. Stack tecnológico propuesto

| Capa | Tecnología | Notas |
|---|---|---|
| Frontend | Next.js + React + TypeScript | UI, navegación, formularios (Challenge Builder, Intelligence Board, etc.) |
| Backend | Convex | Funciones backend, reactividad, orquestación de datos |
| Base de datos | Convex Database | Modelo de entidades de `04-data/data-model.md` |
| Storage | Convex Storage (o capa compatible aprobada) | Archivos, datasets, adjuntos de evidencia |
| Despliegue | Vercel | Frontend + funciones edge/serverless |
| Repositorio | GitHub | Código, specs y documentación versionados juntos |
| IA | Capa de abstracción sobre Claude u otros modelos aprobados | Ver §3 |

Esta selección es la **propuesta inicial** (Master Spec §35); cualquier cambio de stack es una decisión arquitectónica que requiere aprobación explícita (ver `06-development/development-rules.md`).

## 3. Capa de abstracción de IA (AI Abstraction Layer)

```text
DataGo → AI Service → Model Provider
```

- DataGo (agentes, orquestador, UI) nunca invoca un proveedor de modelo directamente.
- El **AI Service** expone una interfaz estable (prompt, contexto, herramientas, parámetros de salida) independiente del proveedor.
- El **Model Provider** (Claude u otro modelo aprobado) es intercambiable detrás de esa interfaz.
- Objetivo: poder evolucionar de proveedor/modelo sin reescribir agentes, orquestador ni UI.

## 4. Arquitectura de herramientas (Tool Architecture)

Los agentes no acceden a datos o sistemas externos de forma libre: consumen **herramientas controladas** (tools), análogas a las capacidades expuestas al Orchestrator.

Ejemplos de tools: análisis de datos, parsing de archivos, búsqueda/investigación, recuperación de conocimiento (knowledge retrieval), cálculos, extracción estructurada, generación de contenido.

Cada tool debe declarar:

```text
Tool
 ├── name
 ├── description
 ├── inputs
 ├── outputs
 ├── permissions
 └── validation
```

Esto permite:
- Registrar un **Tool Registry** central (ver `03-agents/orchestrator-architecture.md`).
- Auditar qué agente usó qué herramienta, con qué inputs y con qué resultado (Observability, `06-development/development-rules.md`).
- Limitar el alcance de cada agente por permisos, no por confianza implícita.

## 5. Ejecución síncrona vs. asíncrona (decisión pendiente)

El Master Spec (§56) marca explícitamente como decisión arquitectónica pendiente la **estrategia de ejecución síncrona/asíncrona** del Orchestrator. Consideraciones a resolver antes de PHASE 5 del roadmap:

- Ejecuciones cortas (una sola llamada a un agente) podrían resolverse de forma síncrona desde la UI.
- Workflows multi-agente con dependencias (ver `03-agents/orchestrator-architecture.md`) probablemente requieren ejecución asíncrona con estado persistido (`AgentRun`, `Task`) y actualización reactiva vía Convex hacia el frontend.
- Debe definirse cómo se comunican progreso, errores y necesidad de intervención humana en tiempo real sin bloquear la UI.

Este documento no resuelve la decisión; la deja explícita como pendiente de aprobación (Master Spec §56, punto 2).

## 6. Requisitos no funcionales transversales

| Atributo | Requisito |
|---|---|
| Seguridad | Ver `security-architecture.md` |
| Multi-tenancy | Ver `multi-tenancy-architecture.md` |
| Observabilidad | Todo Agent Run debe registrar agente, versión, proyecto, tarea, input, output, estado, duración, modelo, uso/tokens, errores, validación y timestamp |
| Versionado | Agentes, prompts, workflows, tools, lógica de scoring, schemas y especificaciones de producto deben ser versionables |
| Testing | Unit, integration, end-to-end y AI evaluation (ver `06-development/development-rules.md`) |
| Costos de IA | Cada agente debe declarar costo estimado (Agent Hub) para permitir control de consumo |

## 7. Estructura de repositorio propuesta

```text
datago/
│
├── README.md
├── DATAGO_MASTER_SPEC.md
│
├── docs/
│   ├── 01-product/
│   ├── 02-architecture/
│   ├── 03-agents/
│   ├── 04-data/
│   ├── 05-ux/
│   └── 06-development/
│
├── app/
├── components/
├── convex/
├── lib/
├── public/
├── tests/
│
├── .env.example
├── package.json
├── tsconfig.json
└── ...
```

La estructura definitiva de `app/`, `components/`, `convex/`, `lib/` y `tests/` se define en la fase técnica de implementación (PHASE 1 del roadmap), no en esta fase de arquitectura.

## 8. Decisiones técnicas pendientes de aprobación

Trasladadas de Master Spec §56, con dueño funcional sugerido:

| # | Decisión | Documento relacionado |
|---|---|---|
| 1 | Arquitectura exacta del Orchestrator | `03-agents/orchestrator-architecture.md` |
| 2 | Estrategia de ejecución síncrona/asíncrona | Este documento §5 |
| 3 | Estrategia de memoria | `04-data/data-architecture.md` §Project Memory |
| 4 | Modelo final de datos | `04-data/data-model.md` |
| 5 | Sistema de permisos | `security-architecture.md` |
| 6 | Sistema multi-tenant | `multi-tenancy-architecture.md` |
| 7 | AI provider abstraction | Este documento §3 |
| 8 | Tool architecture | Este documento §4 |
| 9 | File processing | `04-data/data-architecture.md` §Data Hub |
| 10 | Evidence model | `04-data/data-architecture.md` §Evidence |
| 11 | Agent evaluation | `06-development/development-rules.md` §AI Evaluation |
| 12 | Observability | Este documento §6 |
| 13 | Deployment architecture | Este documento §1–2 |

Ninguna de estas decisiones se considera cerrada hasta que exista una aprobación explícita registrada (ver `06-development/development-rules.md` §Architectural Checkpoint).
