# Multi-Tenancy Architecture

## 1. Jerarquía de tenancy

```text
USER
 ↓
TEAM
 ↓
ORGANIZATION
 ↓
CLIENTS
 ↓
PROJECTS
```

Esta jerarquía debe existir **desde el inicio**, incluso si el MVP solo expone los niveles superiores de forma simplificada (ver `06-development/roadmap.md` PHASE 2).

## 2. Definición de cada nivel

| Nivel | Definición | Ejemplo |
|---|---|---|
| **User** | Individuo autenticado en DataGo | Un consultor de shopper intelligence |
| **Team** | Conjunto de usuarios que colaboran dentro de un mismo contexto de trabajo | Equipo de insights de una agencia |
| **Organization** | Entidad propietaria de Teams, Workspaces y política de acceso agregada | Una agencia o una compañía |
| **Clients** | Entidad de negocio sobre la que trabaja la Organization (puede o no coincidir con un Workspace) | Un fabricante/retailer cliente de la agencia |
| **Projects** | Iniciativa concreta de negocio, con su propio challenge y ciclo de vida | "Crecimiento en categoría X para Cliente Y" |

Nota: `Workspace` (módulo 9.1 en `01-product/README.md`) es el contenedor operativo que agrupa Projects; se relaciona con Organization/Team a nivel de ownership, y el modelo final de esa relación (Workspace = Organization, o Workspace anidado bajo Organization) es parte de las decisiones pendientes del modelo de datos (`04-data/data-model.md`).

## 3. Requisitos por nivel

Cada nivel de la jerarquía debe tener:

```text
ownership        → quién es dueño de este nivel
permissions       → qué pueden hacer los distintos roles dentro de este nivel
access control    → quién puede entrar y con qué alcance
data isolation    → qué datos son visibles exclusivamente dentro de este nivel
```

## 4. Aislamiento de datos entre tenants

- Ninguna entidad de datos (Project, DataSource, Evidence, Insight, Opportunity, Knowledge, etc.) puede resolverse sin un `tenant scope` explícito asociado (Organization → Client → Project como mínimo).
- Las consultas realizadas por agentes durante un `AgentRun` heredan el `tenant scope` del proyecto que originó la ejecución; el Orchestrator no debe permitir que un agente combine datos de dos tenants distintos en una misma tarea salvo que se trate de Knowledge explícitamente marcado como compartido a nivel Organization (y nunca entre Organizations distintas).
- Este requisito es una extensión directa de `security-architecture.md` §4 (Data Isolation) aplicada específicamente a la jerarquía de tenancy.

## 5. Evolución soportada

La arquitectura debe permitir que un mismo usuario transite de operar de forma individual a operar dentro de una organización compleja sin migración de datos disruptiva:

```text
Individual (User sin Organization formal)
   ↓
Team (colaboración simple)
   ↓
Organization (política y administración centralizadas)
   ↓
Enterprise (seguridad avanzada, administración, escalabilidad — Master Spec §3)
```

## 6. Relación con el MVP

El MVP (ver `06-development/roadmap.md` PHASE 2) implementa Users, Organizations, Workspaces, Projects y permisos básicos — la jerarquía completa de Clients y Enterprise se diseña para no requerir reestructuración futura, pero no se expone completamente en el MVP.

## 7. Decisión pendiente

El "Sistema multi-tenant" exacto (por ejemplo, si `Client` es una entidad propia o un atributo de `Project`/`Workspace`) permanece como decisión arquitectónica pendiente (Master Spec §56, punto 6) y debe resolverse en conjunto con `04-data/data-model.md` antes de PHASE 2 del roadmap.
