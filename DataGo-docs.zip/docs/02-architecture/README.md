# 02 — Architecture

Esta carpeta contiene la arquitectura funcional, técnica, de seguridad y de multi-tenancy de DataGo.

| Documento | Contenido |
|---|---|
| [`functional-architecture.md`](./functional-architecture.md) | Cómo fluye el producto de extremo a extremo: del challenge al deliverable, con estados, validaciones y puntos de decisión |
| [`technical-architecture.md`](./technical-architecture.md) | Stack tecnológico, capas del sistema, capa de abstracción de IA, arquitectura de herramientas (tools) |
| [`security-architecture.md`](./security-architecture.md) | Principios de seguridad: secretos, autorización, aislamiento de datos, auditabilidad |
| [`multi-tenancy-architecture.md`](./multi-tenancy-architecture.md) | Jerarquía User → Team → Organization → Clients → Projects, ownership y aislamiento |

Estos documentos operacionalizan las secciones 7, 8, 21–24, 30–37 y 47–58 de `DATAGO_MASTER_SPEC.md`.
