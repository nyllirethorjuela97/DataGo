# Functional Architecture

## 1. Propósito

Definir **cómo fluye el producto de extremo a extremo**: qué ocurre entre que un usuario define un reto de negocio y recibe un entregable, qué validaciones existen en cada transición y quién (usuario, orquestador, agente) es responsable de cada paso.

## 2. Flujo funcional de extremo a extremo

```text
USER
 ↓
CHALLENGE               (Challenge Builder)
 ↓
UNDERSTANDING            (Orchestrator interpreta el challenge)
 ↓
DATA SOURCES             (Data Hub: fuentes disponibles/añadidas)
 ↓
AGENT SELECTION          (Orchestrator decide qué agentes participan)
 ↓
ORCHESTRATION             (Plan de ejecución, tareas, dependencias)
 ↓
ANALYSIS                 (Agentes ejecutan: Data / Shopper / Research / Trade)
 ↓
EVIDENCE                 (Cada hallazgo se registra con fuente y confianza)
 ↓
INTELLIGENCE              (Insight Agent transforma evidencia en insights)
 ↓
OPPORTUNITIES             (Opportunity Agent prioriza oportunidades)
 ↓
RECOMMENDATIONS           (Vinculadas a oportunidades, accionables)
 ↓
ACTION                   (Human-in-the-loop: aprobar / rechazar / modificar)
 ↓
DELIVERABLES              (Executive summary, reporte, etc.)
```

Este flujo es el **contrato funcional** de DataGo: cualquier módulo nuevo debe insertarse en algún punto de esta cadena, no crear un camino paralelo.

## 3. Ciclo de vida de un Challenge

```text
DRAFT
  │  (usuario completa Challenge Builder)
  ▼
STRUCTURED
  │  (pregunta, objetivo, contexto, categoría, mercado, shopper,
  │   restricciones, horizonte temporal, info disponible, resultado esperado)
  ▼
VALIDATED
  │  (el sistema confirma que hay suficiente información para planificar)
  ▼
IN_ANALYSIS
  │  (Orchestrator crea el plan y ejecuta agentes)
  ▼
INTELLIGENCE_READY
  │  (Evidence, Insights e Hypotheses disponibles en el Intelligence Board)
  ▼
OPPORTUNITIES_READY
  │  (Opportunity Engine produjo oportunidades priorizadas)
  ▼
DELIVERED
  │  (se generó al menos un deliverable)
  ▼
CLOSED / ARCHIVED
```

Reglas de transición:
- No se puede pasar de `DRAFT` a `IN_ANALYSIS` sin pasar por `VALIDATED` (evita ejecutar agentes sobre un challenge ambiguo o incompleto).
- `IN_ANALYSIS` puede requerir intervención humana (ver `03-agents/human-in-the-loop.md`) antes de avanzar a `INTELLIGENCE_READY`.
- Un challenge puede volver de `OPPORTUNITIES_READY` a `IN_ANALYSIS` si el usuario solicita profundizar (loop de refinamiento), sin perder el estado anterior (versionado, ver `06-development/development-rules.md` §Versioning).

## 4. Ciclo de vida de un Agent Run

```text
QUEUED → PLANNED → RUNNING → VALIDATING → COMPLETED
                        │                     │
                        └────→ FAILED ←───────┘
                                  │
                             RETRY / ESCALATE (human review)
```

- `PLANNED`: el Orchestrator ya resolvió inputs, contexto, herramientas y dependencias del run.
- `VALIDATING`: el output del agente se valida contra las reglas del sistema (ver §6) antes de persistirse como Evidence/Insight.
- `FAILED`: puede reintentarse automáticamente (retry con backoff) o escalar a revisión humana si el fallo persiste o el impacto es alto.

## 5. Puntos de decisión (Orchestrator)

| Punto | Pregunta que resuelve | Entrada | Salida |
|---|---|---|---|
| Challenge Analysis | ¿Qué tipo de reto es y qué dominios toca? | Challenge estructurado | Categorías de análisis requeridas |
| Workflow Planning | ¿Qué secuencia de agentes responde mejor al reto? | Categorías + fuentes disponibles | Plan de ejecución (DAG de tareas) |
| Agent Selection | ¿Qué agentes son necesarios (no todos se ejecutan siempre)? | Plan de ejecución | Lista de agentes + orden/paralelismo |
| Task Creation | ¿Qué inputs, contexto y herramientas recibe cada agente? | Agentes seleccionados | Tasks con contrato de entrada/salida |
| Validation | ¿El resultado es confiable y trazable? | Output crudo del agente | Evidence/Insight validado o rechazado |
| Next Step | ¿Qué sigue: otro agente, revisión humana o cierre de fase? | Estado acumulado del run | Siguiente transición del Challenge |

Ver el detalle de esta arquitectura en `03-agents/orchestrator-architecture.md`.

## 6. Reglas funcionales invariantes

1. **No todos los agentes se ejecutan siempre** — el Orchestrator decide el subconjunto necesario según el challenge (Master Spec §10, §40).
2. **Toda salida de un agente debe ser trazable a evidencia** — un insight sin evidencia no es válido (Master Spec Rule 6).
3. **FACT, INTERPRETATION, HYPOTHESIS y RECOMMENDATION nunca se presentan como equivalentes** — cada elemento de inteligencia debe declarar explícitamente su naturaleza (ver `04-data/data-architecture.md` §Intelligence Model).
4. **Cuando no hay evidencia suficiente, el sistema expresa incertidumbre** en lugar de inventar una conclusión (Master Spec Rule 9, principio de AI Reliability).
5. **Human-in-the-loop es un gate funcional, no un adorno de UI** — se activa ante hipótesis críticas, baja confianza, conflicto entre fuentes o decisiones de alto impacto.

## 7. Relación entre módulos y flujo funcional

| Fase del flujo | Módulo de producto responsable |
|---|---|
| CHALLENGE | Challenge Builder |
| DATA SOURCES | Data Hub |
| AGENT SELECTION / ORCHESTRATION | Agent Hub + Agent Orchestrator |
| ANALYSIS / EVIDENCE | Agentes (Data, Shopper, Research, Trade) |
| INTELLIGENCE | Insight Agent + Intelligence Board |
| OPPORTUNITIES / RECOMMENDATIONS | Opportunity Agent + Opportunity Engine |
| ACTION | Human-in-the-loop (dentro de Intelligence Board / Opportunity Engine) |
| DELIVERABLES | Deliverables module |
| (transversal) | Project Memory registra contexto y decisiones en cada fase |

## 8. Ejemplo de flujo real (referencia)

Ver `05-ux/user-journeys.md` §"Real Project Example" para el recorrido completo con el challenge *"Quiero entender cómo crecer en una categoría"*.
