# 04 — Data Architecture

Esta carpeta define qué se almacena en DataGo, cómo se modela la evidencia y la inteligencia, y el modelo de entidades propuesto.

| Documento | Contenido |
|---|---|
| [`data-architecture.md`](./data-architecture.md) | Modelo de inteligencia (Source → Evidence → Insight → Hypothesis → Opportunity → Recommendation), Project Memory, entidades principales |
| [`data-model.md`](./data-model.md) | Modelo de datos propuesto: entidades, campos clave, relaciones |

Estos documentos operacionalizan las secciones 24–30 y 33 de `DATAGO_MASTER_SPEC.md`.
