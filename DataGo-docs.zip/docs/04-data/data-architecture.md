# Data Architecture

## 1. Modelo de inteligencia (Intelligence Model)

Toda la inteligencia que produce DataGo se estructura como una cadena trazable:

```text
SOURCE → EVIDENCE → INSIGHT → HYPOTHESIS → OPPORTUNITY → RECOMMENDATION
```

Ningún elemento de esta cadena puede existir "suelto": un `Insight` debe apuntar a la `Evidence` que lo sustenta, una `Opportunity` debe apuntar a los `Insight`s que la originan, y así sucesivamente. Esta trazabilidad es lo que permite al usuario, desde el Intelligence Board, entender **de dónde proviene cada insight** (Master Spec §9.8).

## 2. Evidence

Cada evidencia debe registrar:

| Campo | Descripción |
|---|---|
| `source` | Origen (dataset, documento, investigación, agente que la produjo) |
| `location` | Ubicación específica dentro de la fuente (página, fila, sección, URL) |
| `content / reference` | El contenido o referencia concreta a lo hallado |
| `date` | Fecha del dato/hallazgo (no la fecha de generación por el agente) |
| `confidence` | Nivel de confianza en la validez de la evidencia |
| `relevance` | Relevancia respecto al challenge en curso |

## 3. Insight

Cada insight debe registrar:

| Campo | Descripción |
|---|---|
| `statement` | La afirmación central del insight |
| `explanation` | Por qué ocurre y qué significa (no solo qué ocurre) |
| `evidence` | Referencias a la(s) `Evidence` que lo sustentan |
| `confidence` | Nivel de confianza |
| `category` | Categoría/dominio (shopper, dato interno, mercado, trade, etc.) |
| `business relevance` | Por qué le importa al negocio |

Un insight que no cumple con "qué ocurre / por qué importa / qué significa" (ver `03-agents/agent-catalog.md` §Insight Agent) no debe considerarse un insight completo.

## 4. Hypothesis

Una hipótesis representa una **interpretación que necesita validación** — se diferencia explícitamente de un hecho (`Evidence`). El sistema nunca debe presentar una hipótesis con el mismo nivel de certeza que un hecho verificado (ver AI Reliability Principles en `06-development/development-rules.md`).

## 5. Opportunity

Una oportunidad debe contener:

| Campo | Descripción |
|---|---|
| `title` | Nombre corto de la oportunidad |
| `description` | Descripción de la oportunidad |
| `source insights` | Insights que la originan |
| `potential impact` | Impacto potencial estimado |
| `feasibility` | Factibilidad de ejecutarla |
| `priority` | Prioridad relativa frente a otras oportunidades |
| `recommended next action` | Siguiente paso sugerido |

Tipos de oportunidad contemplados (Master Spec §9.9): comercial, de shopper, de canal, de portafolio, de comunicación, de experiencia.

## 6. Recommendation

Una recomendación debe:

- estar **basada en evidencia** (no en una intuición del modelo sin respaldo);
- **relacionarse con una oportunidad** concreta;
- ser **accionable** (el usuario puede actuar sobre ella directamente);
- tener una **justificación** explícita.

## 7. Entidades principales del sistema

```text
Users
Organizations
Workspaces
Projects
Challenges
DataSources
Files
Datasets
Agents
AgentRuns
Tasks
Evidence
Insights
Hypotheses
Opportunities
Recommendations
Strategies
Proposals
Deliverables
Knowledge
AuditLogs
```

El detalle de campos y relaciones de cada entidad se desarrolla en `data-model.md`. La implementación final del schema en Convex se define en la fase técnica (no en esta fase de arquitectura).

## 8. Project Memory: niveles de memoria

DataGo debe evolucionar hacia distintos niveles de memoria, cada uno con un alcance de reutilización distinto:

| Nivel | Alcance | Ejemplo de contenido |
|---|---|---|
| **Project Memory** | Específico del proyecto | Decisiones tomadas, contexto del challenge, resultados previos |
| **Client Memory** | Reutilizable dentro de un cliente, a través de sus proyectos | Conocimiento acumulado sobre ese cliente/categoría |
| **Organization Memory** | Conocimiento organizacional | Frameworks, metodologías propias de la organización |
| **Learning Memory** | Aprendizajes derivados de proyectos | Qué funcionó / qué no en retos similares anteriores |
| **Decision Memory** | Registro de decisiones | Qué se aprobó, rechazó o modificó, y por qué (ligado a human-in-the-loop) |

Estos niveles deben respetar el aislamiento de tenancy definido en `02-architecture/multi-tenancy-architecture.md`: Client Memory y Organization Memory nunca cruzan los límites de su Organization propietaria.

## 9. Data Hub: procesamiento de archivos (referencia)

El Data Hub centraliza archivos, datasets, documentos, investigaciones, bases de datos y (a futuro) fuentes externas conectadas vía API. El detalle del pipeline de ingestión/procesamiento de archivos (`File processing`) queda como decisión arquitectónica pendiente (ver `02-architecture/technical-architecture.md` §8, punto 9), a resolver antes de PHASE 4 del roadmap.
