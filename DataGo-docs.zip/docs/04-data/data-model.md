# Data Model (Propuesta Conceptual)

> Este modelo es **conceptual**, no un schema definitivo. Su objetivo es dar suficiente detalle para revisión arquitectónica. La implementación final en Convex se resuelve en la fase técnica, respetando esta forma general salvo decisión explícita en contrario.

## 1. Diagrama de relaciones (alto nivel)

```text
Organization 1───* Workspace 1───* Project
                                     │
                 ┌───────────────────┼────────────────────────┐
                 ▼                   ▼                        ▼
             Challenge          DataSource *───* File/Dataset  Knowledge
                 │                   │
                 │                   └──────────────┐
                 ▼                                  ▼
             AgentRun *───1 Agent               (input a AgentRun)
                 │
                 ▼
               Task *
                 │
                 ▼
             Evidence *───* Insight *───* Hypothesis
                                 │
                                 ▼
                           Opportunity *───* Recommendation
                                 │
                                 ▼
                             Strategy (post-MVP)
                                 │
                                 ▼
                             Proposal (post-MVP)
                                 │
                                 ▼
                            Deliverable

(transversal)  User *───* Organization/Workspace (vía roles)
(transversal)  AuditLog *───1 (cualquier entidad mutable)
```

## 2. Entidades y campos clave propuestos

### User
- `id`, `name`, `email`, `role(s)`, `organizationIds[]`, `createdAt`

### Organization
- `id`, `name`, `plan` (Free/Professional/Team/Enterprise), `settings`, `createdAt`

### Workspace
- `id`, `organizationId`, `name`, `members[]`, `createdAt`

### Project
- `id`, `workspaceId`, `name`, `status` (ver ciclo de vida del Challenge en `02-architecture/functional-architecture.md` §3, a nivel Project puede espejar el estado del Challenge activo), `createdAt`, `memoryRef`

### Challenge
- `id`, `projectId`, `mainQuestion`, `objective`, `context`, `category`, `market`, `shopper`, `constraints`, `timeHorizon`, `availableInformation`, `expectedOutcome`, `status` (`DRAFT` → `CLOSED/ARCHIVED`, ver §3 de functional-architecture)

### DataSource
- `id`, `projectId`, `type` (file/dataset/document/research/database/external-api), `origin`, `createdAt`

### File / Dataset
- `id`, `dataSourceId`, `name`, `format`, `storageRef`, `processingStatus`, `schema` (para datasets estructurados)

### Agent
- `id`, `name`, `description`, `capabilities[]`, `tools[]`, `permissions`, `version`, `status`, `estimatedCost`, `inputsContract`, `outputsContract` (definición completa del Agent Hub, `03-agents/agent-catalog.md`)

### AgentRun
- `id`, `agentId`, `agentVersion`, `projectId`, `challengeId`, `status` (ver ciclo de vida en `functional-architecture.md` §4), `input`, `output`, `model`, `tokensUsage`, `duration`, `errors[]`, `validation`, `startedAt`, `completedAt`

### Task
- `id`, `agentRunId`, `orchestratorPlanId`, `dependsOn[]` (otros `Task.id`), `contextRef`, `toolCalls[]`, `status`

### Evidence
- `id`, `projectId`, `source`, `location`, `content/reference`, `date`, `confidence`, `relevance`, `producedByAgentRunId`

### Insight
- `id`, `projectId`, `statement`, `explanation`, `evidenceIds[]`, `confidence`, `category`, `businessRelevance`, `producedByAgentRunId`, `humanReviewStatus` (ver `03-agents/human-in-the-loop.md`)

### Hypothesis
- `id`, `projectId`, `statement`, `relatedInsightIds[]`, `validationStatus` (pending/validated/rejected), `confidence`

### Opportunity
- `id`, `projectId`, `title`, `description`, `sourceInsightIds[]`, `potentialImpact`, `feasibility`, `priority`, `recommendedNextAction`, `type` (comercial/shopper/canal/portafolio/comunicación/experiencia)

### Recommendation
- `id`, `opportunityId`, `statement`, `justification`, `evidenceIds[]`, `actionable` (bool), `humanReviewStatus`

### Strategy *(post-MVP)*
- `id`, `projectId`, `objectives[]`, `priorities[]`, `territories[]`, `positioning`, `initiatives[]`, `roadmap`

### Solution *(post-MVP)*
- `id`, `strategyId`, `type` (concepto/iniciativa/experiencia/activación/solución comercial), `description`

### Proposal *(post-MVP)*
- `id`, `solutionId`, `content`, `format`, `status`

### Deliverable
- `id`, `projectId`, `type` (executive summary/report/strategy document/presentation/proposal/action plan), `content`, `generatedFrom` (referencias a Insight/Opportunity/Recommendation), `createdAt`

### Knowledge
- `id`, `scope` (project/client/organization), `type` (framework/methodology/previous research/learning), `content`, `ownerId`

### AuditLog
- `id`, `actorId` (usuario o `system`), `action`, `entityType`, `entityId`, `before`, `after`, `timestamp`

## 3. Relaciones clave a respetar

1. **Project → Challenge:** un proyecto puede tener múltiples challenges a lo largo del tiempo (refinamiento), pero típicamente uno activo.
2. **Challenge → DataSource:** un challenge consume fuentes registradas en el Data Hub del proyecto.
3. **AgentRun → Task → Evidence/Insight:** toda pieza de inteligencia debe remontarse a un `AgentRun` (o a una acción humana explícita registrada en `AuditLog`, en el caso de `Modify`).
4. **Insight → Evidence (N:N):** un insight puede sustentarse en múltiples evidencias; una evidencia puede sustentar múltiples insights.
5. **Opportunity → Insight (N:N):** una oportunidad puede derivar de múltiples insights.
6. **Recommendation → Opportunity (N:1):** toda recomendación se ata a una oportunidad concreta (Master Spec §29).
7. **Knowledge.scope** determina el aislamiento de tenancy aplicable (ver `02-architecture/multi-tenancy-architecture.md` §4).

## 4. Cuestiones abiertas para la fase técnica

- ¿`Client` es una entidad propia entre `Organization` y `Project`, o un atributo/etiqueta sobre `Workspace`/`Project`? (ver `02-architecture/multi-tenancy-architecture.md` §7).
- ¿Cómo se versiona un `Insight`/`Recommendation` cuando es modificado por un humano (nueva entidad vs. campo de historial)?
- ¿`Task.dependsOn` se resuelve como grafo explícito en el schema o como estado derivado del `AgentRun` padre?

Estas preguntas deben resolverse como parte de la decisión "Modelo final de datos" (`02-architecture/technical-architecture.md` §8, punto 4) antes de iniciar PHASE 2–5 del roadmap.
