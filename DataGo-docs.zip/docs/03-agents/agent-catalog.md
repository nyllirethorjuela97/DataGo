# Agent Catalog

Especificación individual de cada agente del ecosistema DataGo. Todos siguen la plantilla común definida en `README.md` (Purpose, Inputs, Outputs, Tools, Permissions, Trigger, Dependencies, Validation, Memory, Version, Execution Log).

Estado respecto al MVP: `Required` (parte del MVP), `Later` (post-MVP), según Master Spec §42.

---

## 1. Data Agent — `Required`

**Purpose:** Analizar y estructurar la información disponible.

**Responsibilities:** limpieza, estructuración, clasificación, identificación de patrones, análisis descriptivo, preparación de datos.

**Inputs:** datasets, files, structured data.

**Outputs:** structured data, data summaries, patterns, signals.

**Posición en el pipeline:** primera línea de análisis, junto a Shopper Agent y Research Agent; alimenta al Insight Agent.

---

## 2. Shopper Agent — `Required`

**Purpose:** Analizar comportamiento, necesidades y oportunidades relacionadas con el shopper.

**Responsibilities:** comportamiento, journey, necesidades, motivaciones, fricciones, momentos, misiones, barreras, drivers.

**Outputs:** shopper insights, behavioral patterns, shopper opportunities.

**Posición en el pipeline:** primera línea de análisis, en paralelo a Data Agent y Research Agent.

---

## 3. Research Agent — `Required`

**Purpose:** Investigar la información necesaria para responder el challenge.

**Responsibilities:** investigación, búsqueda de información, análisis de fuentes, identificación de señales externas.

**Regla específica:** debe diferenciar explícitamente entre *información encontrada*, *interpretación* y *hipótesis* — nunca presentarlas mezcladas (alineado con AI Reliability Principles).

**Posición en el pipeline:** primera línea de análisis, en paralelo a Data Agent y Shopper Agent.

---

## 4. Insight Agent — `Required`

**Purpose:** Transformar evidencia en inteligencia.

**Modelo interno:**

```text
Evidence → Pattern → Interpretation → Insight
```

**Regla específica:** un insight no es una descripción de datos. Debe explicar **qué ocurre**, **por qué importa** y **qué significa** para el negocio.

**Posición en el pipeline:** consolida las salidas de Data, Shopper y Research Agent antes de pasar a Opportunity Agent.

---

## 5. Opportunity Agent — `Required`

**Purpose:** Convertir insights en oportunidades.

**Modelo interno:**

```text
Insight → Business Implication → Opportunity
```

**Responsibilities:** priorización de oportunidades según criterios definidos (impacto potencial, factibilidad, prioridad — ver `04-data/data-architecture.md` §Opportunity).

**Posición en el pipeline:** recibe insights consolidados y produce las oportunidades que alimentan Trade/Strategy Agent o directamente el Opportunity Engine.

---

## 6. Trade Agent — `Later`

**Purpose:** Interpretar implicaciones comerciales y de trade.

**Puede analizar:** canales, categorías, puntos de venta, ejecución, promociones, portafolio, shopper journey, conversión.

**Estado:** no forma parte del MVP; se incorpora en una fase posterior sin requerir reconstrucción del sistema (arquitectura de agentes diseñada para extensión).

---

## 7. Strategy Agent — `Later`

**Purpose:** Convertir oportunidades en dirección estratégica.

**Trabaja sobre:** objetivos, prioridades, territorios, posicionamiento, iniciativas, roadmap.

**Estado:** no forma parte del MVP. Relacionado con el módulo de producto **Strategy Workspace** (`01-product/README.md` §9.10), también post-MVP.

---

## 8. Solution Agent — `Later`

**Purpose:** Convertir estrategia en soluciones concretas.

**Puede producir:** conceptos, iniciativas, experiencias, activaciones, soluciones comerciales.

**Estado:** no forma parte del MVP.

---

## 9. Proposal Agent — `Later`

**Purpose:** Convertir soluciones en propuestas y entregables profesionales.

**Puede producir:** propuestas, executive summaries, documentos, presentaciones, recomendaciones estructuradas.

**Nota:** pertenece principalmente a fases posteriores del producto; se relaciona con el módulo **Proposal Builder** (`01-product/README.md` §9.11), también post-MVP.

---

## Resumen de dependencias entre agentes

```text
                       ORCHESTRATOR
                            │
          ┌─────────────────┼─────────────────┐
          ↓                 ↓                 ↓
      DATA AGENT       SHOPPER AGENT    RESEARCH AGENT
          │                 │                 │
          └─────────────────┼─────────────────┘
                            ↓
                      INSIGHT AGENT
                            ↓
                    OPPORTUNITY AGENT
                            ↓
                       TRADE AGENT        ← Later
                            ↓
                     STRATEGY AGENT       ← Later
                            ↓
                     SOLUTION AGENT       ← Later
                            ↓
                    PROPOSAL AGENT        ← Later
```

## Tabla resumen

| Agente | Fase MVP | Inputs principales | Output principal | Depende de |
|---|---|---|---|---|
| Data Agent | Required | datasets, files | structured data, patterns | — |
| Shopper Agent | Required | datos de shopper/journey | shopper insights, opportunities | — |
| Research Agent | Required | fuentes externas | información, hipótesis | — |
| Insight Agent | Required | evidencia de los 3 anteriores | insights | Data, Shopper, Research |
| Opportunity Agent | Required | insights | oportunidades priorizadas | Insight Agent |
| Trade Agent | Later | oportunidades + contexto comercial | implicaciones de trade | Opportunity Agent |
| Strategy Agent | Later | oportunidades / trade | dirección estratégica | Opportunity / Trade Agent |
| Solution Agent | Later | estrategia | soluciones concretas | Strategy Agent |
| Proposal Agent | Later | soluciones | propuestas, entregables | Solution Agent |
