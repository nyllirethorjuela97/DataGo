# Orchestrator Architecture

## 1. Rol

El Orchestrator es el **cerebro operativo de DataGo**. Es el único componente que decide qué agentes se ejecutan, en qué orden, con qué contexto, y qué se hace con sus resultados. Ningún agente se autoinvoca ni decide su propia participación en un workflow.

## 2. Pipeline del Orchestrator

```text
CHALLENGE
   ↓
CHALLENGE ANALYSIS       → interpreta el reto: dominio, tipo de pregunta, alcance
   ↓
WORKFLOW PLANNING        → construye un plan (DAG) de tareas y dependencias
   ↓
AGENT SELECTION          → decide qué agentes participan (no todos siempre)
   ↓
TASK CREATION            → define inputs, contexto y herramientas por tarea
   ↓
AGENT EXECUTION          → ejecuta agentes (secuencial y/o paralelo según el DAG)
   ↓
VALIDATION               → valida cada output antes de persistirlo
   ↓
RESULT STORAGE           → guarda Evidence / Insights / Hypotheses / Opportunities
   ↓
NEXT STEP                → decide si continúa el pipeline, pide intervención
                            humana, o cierra la fase
```

## 3. Responsabilidades

El Orchestrator controla: workflow, tareas, agentes, contexto, dependencias, ejecución, validación, errores, retries, estado y trazabilidad.

| Responsabilidad | Descripción |
|---|---|
| Workflow | Mantiene el plan vigente (DAG de tareas) para el challenge en curso |
| Context | Construye y entrega a cada agente exactamente el contexto que necesita (nunca más de lo permitido por el tenant scope, ver `02-architecture/multi-tenancy-architecture.md`) |
| Dependencies | Garantiza que un agente no se ejecute antes de que sus inputs (outputs de otro agente) estén disponibles y validados |
| Execution | Dispara `AgentRun`s siguiendo el ciclo de vida definido en `02-architecture/functional-architecture.md` §4 |
| Validation | Aplica las reglas de validación (evidencia suficiente, ausencia de contradicciones críticas no resueltas, formato esperado) antes de aceptar un output |
| Errors / Retries | Reintenta automáticamente fallos transitorios; escala a revisión humana ante fallos persistentes o de alto impacto |
| State | Mantiene el estado del challenge y de cada `AgentRun`/`Task` sincronizado y consultable en tiempo real |
| Traceability | Cada resultado debe poder trazarse hasta el agente, versión, inputs y evidencia que lo originaron |

## 4. Agent Registry y Tool Registry

Dos registros centrales sostienen al Orchestrator (Master Spec PHASE 5):

- **Agent Registry:** catálogo operativo de agentes disponibles, con su definición completa (Purpose, Inputs, Outputs, Tools, Permissions, Trigger, Dependencies, Validation, Memory, Version). Es la fuente que el Orchestrator consulta en `AGENT SELECTION`. Corresponde al módulo de producto **Agent Hub** (`01-product/README.md` §9.6).
- **Tool Registry:** catálogo de herramientas controladas (`02-architecture/technical-architecture.md` §4) que los agentes pueden invocar, con sus propios permisos y validaciones.

## 5. Agent Selection: cómo decide qué agentes ejecutar

El Orchestrator no ejecuta un pipeline fijo. Decide el subconjunto de agentes según:

1. El **tipo de challenge** (qué categorías de análisis implica: datos internos, comportamiento de shopper, contexto externo/mercado, implicaciones de trade, etc.).
2. Las **fuentes disponibles** en el Data Hub del proyecto (un agente sin inputs suficientes no se planifica).
3. El **resultado esperado** declarado en el Challenge Builder (si el usuario solo pide entendimiento, el pipeline puede detenerse en Intelligence sin llegar a Opportunity/Trade/Strategy).
4. El **alcance del MVP** (ver `06-development/roadmap.md` PHASE 6): en el MVP, el conjunto disponible para selección son Data, Shopper, Research, Insight y Opportunity Agent; Trade, Strategy, Solution y Proposal Agent quedan fuera hasta fases posteriores.

Ejemplo de decisión: un challenge centrado exclusivamente en "estructurar y limpiar un dataset interno" puede requerir únicamente Data Agent → Insight Agent, sin activar Shopper Agent ni Research Agent.

## 6. Validación de resultados

Antes de que un output de agente se convierta en `Evidence`/`Insight`/`Hypothesis` persistente, el Orchestrator valida:

- Que el output declare su **fuente** (Evidence model, `04-data/data-architecture.md` §Evidence).
- Que se respete la separación **FACT / INTERPRETATION / HYPOTHESIS / RECOMMENDATION** (AI Reliability, `06-development/development-rules.md`).
- Que el formato de salida sea consumible por el siguiente agente/módulo en el DAG.
- Que no existan señales de datos inventados (Master Spec Rule 9); en caso de duda, el resultado se marca con confianza baja en lugar de descartarse silenciosamente.

## 7. Manejo de errores

```text
AGENT EXECUTION FAILS
        ↓
   ¿Error transitorio?
    ├── Sí → RETRY (con backoff, límite de intentos)
    └── No → ESCALATE
                 ↓
          Human Review (ver human-in-the-loop.md)
                 ↓
      Approve fallback / Modify / Cancel task
```

## 8. Ejecución síncrona vs. asíncrona

Esta es una decisión arquitectónica pendiente de aprobación — ver `02-architecture/technical-architecture.md` §5. El diseño del Orchestrator debe ser compatible con ambos modelos hasta que se resuelva: el pipeline descrito en §2 no asume síncrono ni asíncrono, solo un orden de responsabilidades.

## 9. Relación con Project Memory

El Orchestrator lee y escribe en `Project Memory` (`04-data/data-architecture.md` §Project Memory) en cada fase relevante: registra decisiones de planificación, agentes ejecutados y resultados clave, de forma que un challenge posterior en el mismo proyecto pueda beneficiarse del contexto acumulado.
