# Human in the Loop

## 1. Propósito

DataGo es agentic, no autónomo sin supervisión. La arquitectura debe garantizar que un humano pueda intervenir en momentos específicos y bien definidos del flujo, sin convertir cada paso en un cuello de botella manual.

## 2. Condiciones de activación

DataGo debe permitir intervención humana cuando:

- una **hipótesis sea crítica** para la recomendación final;
- exista **baja confianza** en un insight u oportunidad;
- se **requiera aprobación** explícita antes de avanzar (por ejemplo, antes de generar un deliverable);
- exista **conflicto entre fuentes** (dos evidencias contradictorias sin resolución automática clara);
- una **decisión tenga impacto significativo** en el negocio del cliente.

## 3. Flujo de intervención

```text
AI Recommendation
       ↓
Human Review
       ↓
Approve / Reject / Modify
       ↓
Continue Workflow
```

- **Approve:** el elemento (insight, hipótesis, oportunidad, recomendación) se marca como validado por humano y continúa el pipeline sin cambios.
- **Reject:** el elemento se descarta explícitamente; el Orchestrator registra el rechazo y puede replanificar (por ejemplo, solicitar más evidencia o reejecutar un agente).
- **Modify:** el humano edita el contenido (por ejemplo, ajusta el texto de una recomendación o su prioridad); la versión modificada queda registrada junto a la versión original generada por IA (trazabilidad, ver `06-development/development-rules.md` §Versioning).

## 4. Dónde ocurre en la UX

La intervención humana se expone principalmente en:

- **Intelligence Board** (`01-product/README.md` §9.8): revisión de insights/hipótesis antes de que se conviertan en oportunidades.
- **Opportunity Engine** (`01-product/README.md` §9.9): aprobación o ajuste de oportunidades y recomendaciones antes de pasar a Action/Deliverables.

## 5. Relación con el Orchestrator

El Orchestrator es quien detecta las condiciones de §2 (por ejemplo, mediante un umbral de confianza mínimo o la detección de contradicciones entre evidencias) y **pausa** el `AgentRun`/`Task` correspondiente hasta recibir una decisión humana, en vez de forzar una conclusión automática. Ver `orchestrator-architecture.md` §7 (Manejo de errores) para el caso de escalamiento por fallo, que sigue el mismo patrón de pausa-y-revisión.

## 6. Registro y auditabilidad

Toda decisión humana dentro de este flujo debe registrarse en `AuditLogs` con: usuario, timestamp, elemento afectado, decisión tomada (approve/reject/modify) y, si aplica, el contenido antes/después de la modificación (ver `02-architecture/security-architecture.md` §5 y `04-data/data-model.md`).
