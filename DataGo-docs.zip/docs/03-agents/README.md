# 03 — Agent Architecture

Esta carpeta define la arquitectura de agentes de DataGo: el orquestador que los controla, el catálogo completo de agentes y el modelo de intervención humana.

| Documento | Contenido |
|---|---|
| [`orchestrator-architecture.md`](./orchestrator-architecture.md) | El cerebro operativo de DataGo: planificación, selección de agentes, ejecución, validación y manejo de errores |
| [`agent-catalog.md`](./agent-catalog.md) | Especificación de cada agente (Data, Shopper, Research, Insight, Opportunity, Trade, Strategy, Solution, Proposal) |
| [`human-in-the-loop.md`](./human-in-the-loop.md) | Cuándo y cómo interviene un humano en el flujo agentic |

## Arquitectura general de agentes

```text
                       ORCHESTRATOR
                            │
          ┌─────────────────┼─────────────────┐
          ↓                 ↓                 ↓
      DATA AGENT       SHOPPER AGENT    RESEARCH AGENT
          │                 │                 │
          └─────────────────┼─────────────────┘
                            ↓
                      INSIGHT AGENT
                            ↓
                    OPPORTUNITY AGENT
                            ↓
                       TRADE AGENT
                            ↓
                     STRATEGY AGENT
                            ↓
                     SOLUTION AGENT
                            ↓
                    PROPOSAL AGENT
```

Este diagrama representa el **modelo conceptual**. La implementación real permite workflows distintos según el challenge: **no todos los proyectos ejecutan todos los agentes** (ver `orchestrator-architecture.md` §Agent Selection).

## Principios que todo agente debe cumplir

Cada agente debe ser: especializado, modular, trazable, controlable, versionable, evaluable y limitado por permisos. Cada agente debe declarar:

```text
Agent
 ├── Purpose
 ├── Inputs
 ├── Outputs
 ├── Tools
 ├── Permissions
 ├── Trigger
 ├── Dependencies
 ├── Validation
 ├── Memory
 ├── Version
 └── Execution Log
```
